const bulawayoCities = [
    {
        "name": "Bulawayo",
        "province": "Bulawayo",
        "latitude": -20.0012,
        "longitude": 28.6295
    },
    {
        "name": "Barham Green",
        "province": "Bulawayo",
        "latitude": -20.0723,
        "longitude": 28.5856
    },
    {
        "name": "Beacon Hill",
        "province": "Bulawayo",
        "latitude": -20.0525,
        "longitude": 28.6283
    },
    {
        "name": "Bellevue",
        "province": "Bulawayo",
        "latitude": -20.0582,
        "longitude": 28.5900
    },
    {
        "name": "Belmont",
        "province": "Bulawayo",
        "latitude": -20.0528,
        "longitude": 28.5781
    },
    {
        "name": "Bradfield",
        "province": "Bulawayo",
        "latitude": -20.0194,
        "longitude": 28.5639
    },
    {
        "name": "Burnside",
        "province": "Bulawayo",
        "latitude": -20.0511,
        "longitude": 28.6064
    },
    {
        "name": "Cowdray Park",
        "province": "Bulawayo",
        "latitude": -20.0634,
        "longitude": 28.6041
    },
    {
        "name": "Entumbane",
        "province": "Bulawayo",
        "latitude": -20.0487,
        "longitude": 28.6205
    },
    {
        "name": "Famona",
        "province": "Bulawayo",
        "latitude": -20.0146,
        "longitude": 28.5701
    }
];

const harareSuburbs = [
    {
        "name": "Avondale",
        "province": "Harare",
        "latitude": -17.8228,
        "longitude": 31.0323
    },
    {
        "name": "Borrowdale",
        "province": "Harare",
        "latitude": -17.7546,
        "longitude": 31.0484
    },
    {
        "name": "Belgravia",
        "province": "Harare",
        "latitude": -17.8250,
        "longitude": 31.0362
    },
    {
        "name": "Greendale",
        "province": "Harare",
        "latitude": -17.8221,
        "longitude": 31.0588
    },
    {
        "name": "Mount Pleasant",
        "province": "Harare",
        "latitude": -17.8075,
        "longitude": 31.0613
    },
    {
        "name": "Highlands",
        "province": "Harare",
        "latitude": -17.7628,
        "longitude": 31.0797
    },
    {
        "name": "Eastlea",
        "province": "Harare",
        "latitude": -17.8279,
        "longitude": 31.0562
    },
    {
        "name": "Mabvuku",
        "province": "Harare",
        "latitude": -17.9721,
        "longitude": 31.0611
    },
    {
        "name": "Waterfalls",
        "province": "Harare",
        "latitude": -17.9733,
        "longitude": 31.0594
    },
    {
        "name": "Emerald Hill",
        "province": "Harare",
        "latitude": -17.9792,
        "longitude": 31.0278
    },
    {
        "name": "Chisipite",
        "province": "Harare",
        "latitude": -17.7591,
        "longitude": 31.0526
    },
    {
        "name": "Kuwadzana",
        "province": "Harare",
        "latitude": -17.9628,
        "longitude": 31.0614
    }
];

const mashonalandWestCities = [
    {
        "name": "Chinhoyi",
        "province": "Mashonaland West",
        "latitude": -17.3667,
        "longitude": 30.2000
    },
    {
        "name": "Kadoma",
        "province": "Mashonaland West",
        "latitude": -19.1965,
        "longitude": 29.9131
    },
    {
        "name": "Chegutu",
        "province": "Mashonaland West",
        "latitude": -18.1803,
        "longitude": 29.7459
    },
    {
        "name": "Kariba",
        "province": "Mashonaland West",
        "latitude": -16.5455,
        "longitude": 28.8255
    },
    {
        "name": "Norton",
        "province": "Mashonaland West",
        "latitude": -17.9828,
        "longitude": 30.5564
    },
    {
        "name": "Hurungwe",
        "province": "Mashonaland West",
        "latitude": -16.7986,
        "longitude": 29.5844
    },
    {
        "name": "Makonde",
        "province": "Mashonaland West",
        "latitude": -16.8539,
        "longitude": 30.0211
    },
    {
        "name": "Mhondoro-Ngezi",
        "province": "Mashonaland West",
        "latitude": -18.0956,
        "longitude": 29.7632
    },
    {
        "name": "Sanyati",
        "province": "Mashonaland West",
        "latitude": -17.0000,
        "longitude": 30.5000
    },
    {
        "name": "Zvimba",
        "province": "Mashonaland West",
        "latitude": -17.4077,
        "longitude": 30.0972
    },
    {
        "name": "Karoi",
        "province": "Mashonaland West",
        "latitude": -16.8181,
        "longitude": 29.7408
    },
    {
        "name": "Gadzema",
        "province": "Mashonaland West",
        "latitude": -18.0422,
        "longitude": 30.1597
    }
];

const mashonalandEastCities = [
    {
        "name": "Marondera",
        "province": "Mashonaland East",
        "latitude": -18.1736,
        "longitude": 31.5500
    },
    {
        "name": "Chivhu",
        "province": "Mashonaland East",
        "latitude": -19.0403,
        "longitude": 30.9633
    },
    {
        "name": "Beatrice",
        "province": "Mashonaland East",
        "latitude": -18.4914,
        "longitude": 30.7842
    },
    {
        "name": "Mudzi",
        "province": "Mashonaland East",
        "latitude": -16.6619,
        "longitude": 30.9347
    },
    {
        "name": "Goromonzi",
        "province": "Mashonaland East",
        "latitude": -17.7240,
        "longitude": 31.1335
    },
    {
        "name": "Macheke",
        "province": "Mashonaland East",
        "latitude": -18.1533,
        "longitude": 31.5200
    },
    {
        "name": "Mutoko",
        "province": "Mashonaland East",
        "latitude": -16.9667,
        "longitude": 31.4833
    },
    {
        "name": "Murehwa",
        "province": "Mashonaland East",
        "latitude": -17.4333,
        "longitude": 31.4833
    },
    {
        "name": "Ruwa",
        "province": "Mashonaland East",
        "latitude": -17.7275,
        "longitude": 31.0711
    },
    {
        "name": "Wedza",
        "province": "Mashonaland East",
        "latitude": -18.1222,
        "longitude": 31.3681
    }
];

const manicalandCities = [
    {
        "name": "Mutare",
        "province": "Manicaland",
        "latitude": -18.9711,
        "longitude": 32.5892
    },
    {
        "name": "Chipinge",
        "province": "Manicaland",
        "latitude": -20.2000,
        "longitude": 32.6000
    },
    {
        "name": "Rusape",
        "province": "Manicaland",
        "latitude": -18.9472,
        "longitude": 31.6100
    },
    {
        "name": "Buhera",
        "province": "Manicaland",
        "latitude": -20.0597,
        "longitude": 31.7644
    },
    {
        "name": "Nyanga",
        "province": "Manicaland",
        "latitude": -19.1000,
        "longitude": 32.9000
    },
    {
        "name": "Makoni",
        "province": "Manicaland",
        "latitude": -18.9500,
        "longitude": 31.5000
    },
    {
        "name": "Hwedza",
        "province": "Manicaland",
        "latitude": -18.3000,
        "longitude": 31.4000
    },
    {
        "name": "Mutasa",
        "province": "Manicaland",
        "latitude": -18.8000,
        "longitude": 32.5000
    },
    {
        "name": "Marange",
        "province": "Manicaland",
        "latitude": -20.0500,
        "longitude": 32.7000
    },
    {
        "name": "Chimanimani",
        "province": "Manicaland",
        "latitude": -19.8833,
        "longitude": 32.6000
    }
];

const masvingoCities = [
    {
        "name": "Masvingo",
        "province": "Masvingo",
        "latitude": -19.0674,
        "longitude": 30.8354
    },
    {
        "name": "Chiredzi",
        "province": "Masvingo",
        "latitude": -20.0215,
        "longitude": 31.6403
    },
    {
        "name": "Gutu",
        "province": "Masvingo",
        "latitude": -20.0681,
        "longitude": 30.5615
    },
    {
        "name": "Bikita",
        "province": "Masvingo",
        "latitude": -20.0578,
        "longitude": 30.2056
    },
    {
        "name": "Mwenezi",
        "province": "Masvingo",
        "latitude": -21.0000,
        "longitude": 30.5000
    },
    {
        "name": "Zaka",
        "province": "Masvingo",
        "latitude": -20.0500,
        "longitude": 31.6000
    },
    {
        "name": "Triangle",
        "province": "Masvingo",
        "latitude": -20.0667,
        "longitude": 31.6333
    },
    {
        "name": "Jerera",
        "province": "Masvingo",
        "latitude": -19.9900,
        "longitude": 31.0600
    },
    {
        "name": "Neshuro",
        "province": "Masvingo",
        "latitude": -20.1385,
        "longitude": 30.7102
    },
    {
        "name": "Rutenga",
        "province": "Masvingo",
        "latitude": -19.7700,
        "longitude": 30.6400
    }
];

const midlandsCities = [
    {
        "name": "Gweru",
        "province": "Midlands",
        "latitude": -19.4467,
        "longitude": 29.8156
    },
    {
        "name": "Kwekwe",
        "province": "Midlands",
        "latitude": -19.1965,
        "longitude": 29.9131
    },
    {
        "name": "Zvishavane",
        "province": "Midlands",
        "latitude": -20.2531,
        "longitude": 29.9944
    },
    {
        "name": "Shurugwi",
        "province": "Midlands",
        "latitude": -19.0889,
        "longitude": 29.7392
    },
    {
        "name": "Redcliff",
        "province": "Midlands",
        "latitude": -19.1333,
        "longitude": 29.8833
    },
    {
        "name": "Gokwe Centre",
        "province": "Midlands",
        "latitude": -18.2500,
        "longitude": 29.8000
    },
    {
        "name": "Mvuma",
        "province": "Midlands",
        "latitude": -19.0528,
        "longitude": 30.3956
    },
    {
        "name": "Mberengwa",
        "province": "Midlands",
        "latitude": -20.0000,
        "longitude": 30.0000
    },
    {
        "name": "Chirumhanzu",
        "province": "Midlands",
        "latitude": -18.6000,
        "longitude": 30.2000
    }
];

const matabelelandNorthCities = [
    {
        "name": "Hwange",
        "province": "Matabeleland North",
        "latitude": -19.3167,
        "longitude": 27.5000
    },
    {
        "name": "Victoria Falls",
        "province": "Matabeleland North",
        "latitude": -17.9333,
        "longitude": 25.8333
    },
    {
        "name": "Binga",
        "province": "Matabeleland North",
        "latitude": -17.0000,
        "longitude": 27.0000
    },
    {
        "name": "Dete",
        "province": "Matabeleland North",
        "latitude": -18.6333,
        "longitude": 27.3833
    },
    {
        "name": "Lupane",
        "province": "Matabeleland North",
        "latitude": -17.5261,
        "longitude": 27.7769
    },
    {
        "name": "Nkayi",
        "province": "Matabeleland North",
        "latitude": -19.0667,
        "longitude": 28.1667
    },
    {
        "name": "Tsholotsho",
        "province": "Matabeleland North",
        "latitude": -18.8000,
        "longitude": 27.2000
    },
    {
        "name": "Gokwe North",
        "province": "Matabeleland North",
        "latitude": -18.2500,
        "longitude": 28.5000
    },
    {
        "name": "Gokwe South",
        "province": "Matabeleland North",
        "latitude": -18.5000,
        "longitude": 28.7500
    }
];

const matabelelandSouthCities = [
    {
        "name": "Gwanda",
        "province": "Matabeleland South",
        "latitude": -20.0833,
        "longitude": 29.0667
    },
    {
        "name": "Beitbridge",
        "province": "Matabeleland South",
        "latitude": -22.0167,
        "longitude": 30.0000
    },
    {
        "name": "Plumtree",
        "province": "Matabeleland South",
        "latitude": -20.2500,
        "longitude": 28.9833
    },
    {
        "name": "Filabusi",
        "province": "Matabeleland South",
        "latitude": -20.2000,
        "longitude": 29.3500
    },
    {
        "name": "Esigodini",
        "province": "Matabeleland South",
        "latitude": -20.2000,
        "longitude": 29.5000
    },
    {
        "name": "Fort Rixon",
        "province": "Matabeleland South",
        "latitude": -20.3000,
        "longitude": 29.6000
    },
    {
        "name": "Brunapeg",
        "province": "Matabeleland South",
        "latitude": -20.2500,
        "longitude": 29.2000
    },
    {
        "name": "Antelope Mine",
        "province": "Matabeleland South",
        "latitude": -20.4000,
        "longitude": 29.8000
    },
    {
        "name": "Kafusi",
        "province": "Matabeleland South",
        "latitude": -20.5000,
        "longitude": 29.7000
    },
    {
        "name": "Kezi",
        "province": "Matabeleland South",
        "latitude": -20.4500,
        "longitude": 28.7500
    }
];

