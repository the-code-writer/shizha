const farmers = [
    {
        "firstName": "Alice",
        "lastName": "Ngwenya",
        "gender": "Female",
        "dateOfBirth": "1985-04-12",
        "idNumber": "1234567890123",
        "address": "456 Farm Lane, Harare, Zimbabwe",
        "email": "alice.ngwenya@example.com",
        "phone": "+263 77 123 4567",
        "qualifications": ["Diploma in Agriculture"],
        "numberOfLivestock": {
            "cattle": 20,
            "sheep": 15,
            "goats": 10,
            "poultry": 50
        },
        "typesOfCrops": ["Maize", "Soybeans", "Tobacco"],
        "yearJoining": 2010,
        "growerNumber": 1001,
        "averageYield": {
            "maize": 5, // in tons per hectare
            "soybeans": 2.5, // in tons per hectare
            "tobacco": 1.2 // in tons per hectare
        },
        "district": "Harare"
    },
    {
        "firstName": "Tendai",
        "lastName": "Moyo",
        "gender": "Male",
        "dateOfBirth": "1990-08-22",
        "idNumber": "9876543210987",
        "address": "789 Greenfield St, Bulawayo, Zimbabwe",
        "email": "tendai.moyo@example.com",
        "phone": "+263 77 765 4321",
        "qualifications": ["BSc Agriculture"],
        "numberOfLivestock": {
            "cattle": 15,
            "sheep": 25,
            "pigs": 5,
            "poultry": 100
        },
        "typesOfCrops": ["Wheat", "Barley", "Cotton"],
        "yearJoining": 2015,
        "growerNumber": 1002,
        "averageYield": {
            "wheat": 4, // in tons per hectare
            "barley": 3.5, // in tons per hectare
            // Add more crop yields as necessary
        },
        "district": "Bulawayo"
    },
    {
        "firstName": "Michael",
        "lastName": "Chikanga",
        "gender": "Male",
        "dateOfBirth": null,
        // Use null for unknown dates
        // Continue filling in the rest of the details...
    },
    {
        // Add more farmers here...
        // Example:
        // firstName: "...", lastName: "...", etc.
    }
];

// Continue adding more farmers up to a total of desired entries...